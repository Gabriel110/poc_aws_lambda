#!/usr/bin/env bash
cd ..
serverless deploy --stage local
#serverless info --stage local
exit