#!/usr/bin/env bash
cd ..
serverless invoke local -f handler